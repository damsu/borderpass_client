app.controller('preferencesCtrl', ["$scope", function ($scope) {

}]);
