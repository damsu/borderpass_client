app.controller('myreservationsCtrl', ["$scope", function ($scope) {

}]);
