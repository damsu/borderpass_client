app.controller('homeCtrl', ["$scope", function ($scope) {

}]);
